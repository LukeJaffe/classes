#!/bin/bash

jupyter notebook
